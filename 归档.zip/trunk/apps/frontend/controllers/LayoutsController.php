<?php
namespace Mdg\Frontend\Controllers;
use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;
use Mdg\Models as M;
use Lib\File as File;
use \Sell as Sell;
use Lib\Func as Func;
class IndexController extends ControllerBase
{
   

}

?>