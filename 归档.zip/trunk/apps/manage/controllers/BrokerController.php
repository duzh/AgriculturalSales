<?php
/**
 * @file BrokerController.php
 * @brief 经纪人管理 
 * @author huangb
 * @version 
 * @date 2015-09-28
 */
namespace Mdg\Manage\Controllers;

class Broker extends ControllerMember
{
	public function indexAction(){
		
	}	





}
