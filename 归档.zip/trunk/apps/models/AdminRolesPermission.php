<?php
namespace Mdg\Models;
class AdminRolesPermission extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     */
    public $role_id=0;

    /**
     *
     * @var integer
     */
    public $permission_id=0;

}
