<?php
namespace Mdg\Models;
class Village extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     */
    public $id;

    /**
     *
     * @var string
     */
    public $code;

    /**
     *
     * @var string
     */
    public $name;

    /**
     *
     * @var integer
     */
    public $sortrank;

    /**
     *
     * @var integer
     */
    public $tid;

    /**
     *
     * @var string
     */
    public $tcode;

}
