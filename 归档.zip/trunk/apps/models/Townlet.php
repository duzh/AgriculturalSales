<?php
namespace Mdg\Models;
class Townlet extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     */
    public $id;

    /**
     *
     * @var string
     */
    public $code;

    /**
     *
     * @var string
     */
    public $name;

    /**
     *
     * @var string
     */
    public $url;

    /**
     *
     * @var integer
     */
    public $aid;

    /**
     *
     * @var string
     */
    public $pcode;

    /**
     *
     * @var string
     */
    public $vcode;

}
