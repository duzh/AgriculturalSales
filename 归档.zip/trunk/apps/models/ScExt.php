<?php
namespace Mdg\Models;

class ScExt extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     */
    public $id;

    /**
     *
     * @var integer
     */
    public $sc_id;

    /**
     *
     * @var string
     */
    public $net_name;

    /**
     *
     * @var string
     */
    public $company_name;

    /**
     *
     * @var string
     */
    public $contact_man;

    /**
     *
     * @var string
     */
    public $fix_phone;

    /**
     *
     * @var string
     */
    public $mobile_phone;

    /**
     *
     * @var integer
     */
    public $type;

    /**
     *
     * @var string
     */
    public $address;

    /**
     *
     * @var integer
     */
    public $add_time;

    /**
     *
     * @var integer
     */
    public $last_update_time;

    /**
     *
     * @var integer
     */
    public $status;

    

}
