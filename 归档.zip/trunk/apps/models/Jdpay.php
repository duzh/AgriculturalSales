<?php

namespace Mdg\Models;
use Lib as L;
class Jdpay extends \Phalcon\Mvc\Model
{



}
?>