<?php
namespace Mdg\Models;
class SellContent extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     */
    public $sid;

    /**
     *
     * @var string
     */
    public $content;

}
