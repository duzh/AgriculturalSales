<!DOCTYPE HTML>
<html>
<head>
    <title>Ueditor for UPYUN</title>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
    <script src="ueditor.config.js"></script>
    <script src="ueditor.all.min.js"> </script>
    <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
    <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
    <script src="lang/zh-cn/zh-cn.js"></script>
</head>
<body>
    <script id="container" name="content" type="text/plain">
        这里写你的初始化内容
    </script>
    <script>
        var editor = UE.getEditor('container');
    </script>
</body>
</html>
